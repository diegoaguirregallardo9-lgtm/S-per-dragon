COMPILAR AURA CLASH USANDO SOLO IPHONE (SIN COMPUTADORA)

Este proyecto incluye un flujo de GitHub Actions para compilar el APK en la nube.

1. En Safari, crea una cuenta en https://github.com/ (si no tienes una) y crea un repositorio nuevo llamado AuraClash.
2. Descomprime AuraClashAndroid.zip en la app Archivos del iPhone.
3. En el repositorio de GitHub, usa Add file > Upload files y sube TODO el contenido de la carpeta AuraClashAndroid, incluida la carpeta oculta .github.
   IMPORTANTE: la carpeta .github/workflows/build-apk.yml debe quedar en la raíz del repositorio, y settings.gradle debe quedar también en la raíz.
4. Confirma el envío con Commit changes.
5. Abre la pestaña Actions del repositorio y entra en "Build Aura Clash APK". Espera a que termine el trabajo.
6. Abre la ejecución completada y descarga el artefacto "Aura-Clash-APK". Dentro estará app-debug.apk.

Notas:
- La compilación ocurre en los servidores de GitHub; no en el iPhone.
- El APK es una compilación de prueba (debug), no una publicación firmada para Google Play.
- El juego usa recursos remotos (Three.js y fuentes), así que necesita conexión a internet para cargarlos.
