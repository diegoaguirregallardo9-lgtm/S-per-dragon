AURA CLASH — PROYECTO ANDROID

Este ZIP contiene el proyecto Android Studio que envuelve el juego HTML original en una app Android de pantalla completa y orientación horizontal.

PARA GENERAR EL APK:
1. Instala Android Studio en una computadora.
2. Descomprime este ZIP.
3. Abre Android Studio > Open y selecciona la carpeta AuraClashAndroid.
4. Espera a que Gradle sincronice y descargue los componentes necesarios.
5. En el menú Build, selecciona Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará la ubicación del APK generado (normalmente app/build/outputs/apk/debug/app-debug.apk).

NOTAS:
- El juego se conserva como HTML dentro de app/src/main/assets/index.html.
- Requiere conexión a Internet para cargar Three.js y las fuentes externas que el HTML original enlaza desde CDN/Google Fonts.
- Se configura pantalla completa, orientación horizontal y JavaScript/WebGL dentro de WebView.
- Este entorno no tiene Android SDK/Gradle instalado, por lo que aquí se entrega el proyecto listo para abrir y compilar en Android Studio, no un APK ya compilado.
