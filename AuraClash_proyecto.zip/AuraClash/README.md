# AURA CLASH
Juego de peleas 3D (Three.js). El juego está en `www/index.html` (copia en `Index_HTML.html`).

## Subir a GitHub y generar el APK
1. Crea un repositorio nuevo en github.com (vacío).
2. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`). En la web: "Add file > Upload files" y arrastra los archivos.
3. Ve a la pestaña **Actions > Build APK** (se ejecuta solo con cada subida; también puedes pulsar *Run workflow*).
4. Al terminar (unos 5-10 min) abre la ejecución y descarga el artefacto **aura-clash-apk** (`app-debug.apk`).
5. Pásalo al teléfono e instálalo (permite "orígenes desconocidos").

El workflow descarga Three.js desde npm y lo guarda dentro del juego, así funciona sin internet. Las fuentes de Google son opcionales (hay fuentes de respaldo).

## Probar en el navegador
Abre `www/index.html` (necesita internet para Three.js, o ejecuta `npm install && npm run prepare-web`).

## Datos guardados (localStorage)
Monedas, personajes comprados/equipado, victorias, combates, progreso del torneo y ajustes de audio/gráficos.
